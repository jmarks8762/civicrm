<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'wan', 'guo', 'lu', 'hao', 'jie', 'yi', 'chou', 'ju', 'ju', 'cheng', 'zuo', 'liang', 'qiang', 'zhi', 'chui', 'ya',
  0x10 => 'ju', 'bei', 'jiao', 'zhuo', 'zi', 'bin', 'peng', 'ding', 'chu', 'chang', 'men', 'hua', 'jian', 'gui', 'xi', 'du',
  0x20 => 'qian', 'dao', 'gui', 'dian', 'luo', 'zhi', 'quan', 'ming', 'fu', 'geng', 'peng', 'zhan', 'yi', 'tuo', 'sen', 'duo',
  0x30 => 'ye', 'fu', 'wei', 'wei', 'duan', 'jia', 'zong', 'jian', 'yi', 'shen', 'xi', 'yan', 'yan', 'chuan', 'jian', 'chun',
  0x40 => 'yu', 'he', 'zha', 'wo', 'pian', 'bi', 'yao', 'huo', 'xu', 'ruo', 'yang', 'la', 'yan', 'ben', 'hui', 'kui',
  0x50 => 'jie', 'kui', 'si', 'feng', 'xie', 'tuo', 'zhi', 'jian', 'mu', 'mao', 'chu', 'hu', 'hu', 'lian', 'leng', 'ting',
  0x60 => 'nan', 'yu', 'you', 'mei', 'song', 'xuan', 'xuan', 'yang', 'zhen', 'pian', 'ye', 'ji', 'jie', 'ye', 'chu', 'dun',
  0x70 => 'yu', 'zou', 'wei', 'mei', 'ti', 'ji', 'jie', 'kai', 'qiu', 'ying', 'rou', 'huang', 'lou', 'le', 'quan', 'xiang',
  0x80 => 'pin', 'shi', 'gai', 'tan', 'lan', 'wen', 'yu', 'chen', 'lu', 'ju', 'shen', 'chu', 'pi', 'xie', 'jia', 'yi',
  0x90 => 'zhan', 'fu', 'nuo', 'mi', 'lang', 'rong', 'gu', 'jian', 'ju', 'ta', 'yao', 'zhen', 'bang', 'sha', 'yuan', 'zi',
  0xA0 => 'ming', 'su', 'jia', 'yao', 'jie', 'huang', 'gan', 'fei', 'zha', 'qian', 'ma', 'sun', 'yuan', 'xie', 'rong', 'shi',
  0xB0 => 'zhi', 'cui', 'yun', 'ting', 'liu', 'rong', 'tang', 'que', 'zhai', 'si', 'sheng', 'ta', 'ke', 'xi', 'gu', 'qi',
  0xC0 => 'gao', 'gao', 'sun', 'pan', 'tao', 'ge', 'xun', 'dian', 'nou', 'ji', 'shuo', 'gou', 'chui', 'qiang', 'cha', 'qian',
  0xD0 => 'huai', 'mei', 'xu', 'gang', 'gao', 'zhuo', 'tuo', 'qiao', 'yang', 'dian', 'jia', 'kan', 'zui', 'dao', 'long', 'bin',
  0xE0 => 'zhu', 'sang', 'xi', 'ji', 'lian', 'hui', 'yong', 'qian', 'guo', 'gai', 'gai', 'tuan', 'hua', 'qi', 'sen', 'cui',
  0xF0 => 'peng', 'you', 'hu', 'jiang', 'hu', 'huan', 'gui', 'nie', 'yi', 'gao', 'kang', 'gui', 'gui', 'cao', 'man', 'jin',
];
