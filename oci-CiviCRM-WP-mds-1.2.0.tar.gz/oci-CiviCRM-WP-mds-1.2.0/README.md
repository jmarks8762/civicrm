# oci-CiviCRM-WP-mds

Deploy CiviCRM with Wordpress on Oracle Cloud Intrastructure (OCI) and MySQL Database Service (MDS) using these Terraform modules.

The same modules are used as Resource Manager Stack.

The latest stack can be downloaded directly in the releases (the zip file)

[![Deploy to Oracle Cloud](https://oci-resourcemanager-plugin.plugins.oci.oraclecloud.com/latest/deploy-to-oracle-cloud.svg)](https://cloud.oracle.com/resourcemanager/stacks/create?zipUrl=https://github.com/lefred/oci-CiviCRM-WP-mds/releases/download/v1.2.0/stack_civicrmWP_mds.zip)
