#!/bin/bash

# Script to create a stack to use in OCI Resource Manager

cd stack
zip -r ../stack_civicrmWP_mds.zip *
cd -
